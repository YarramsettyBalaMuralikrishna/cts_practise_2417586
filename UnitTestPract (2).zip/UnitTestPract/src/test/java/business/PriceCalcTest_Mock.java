package business;

import com.data.api.ProductService;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

public class PriceCalcTest_Mock {

    @Test
    public void priceCalculatorTest(){
        ProductService mockService = mock(ProductService.class);

        when(mockService.getProductPrice("Apple")).thenReturn(100);

        PriceCalculator priceCalculator = new PriceCalculator(mockService);

        double calculatedDiscount = priceCalculator.calculateDiscount("Apple");

        assertEquals(90.0, calculatedDiscount, 0.000001);

        verify(mockService, times(1)).getProductPrice("Apple");
    }

    @Test
    public void testLIst(){
        List listMock = mock(List.class);
        when(listMock.size()).thenReturn(0).thenThrow(new RuntimeException("not found"));
        assertEquals(false, listMock.contains(2));
        assertEquals(0, listMock.size());
        assertEquals(0, listMock.size());

        verify(listMock, times(2)).size();
    }


}
