package business;

import com.data.api.TodoService;
import org.junit.Test;
import stub.TodoServiceStub;

import java.util.List;

import static org.junit.Assert.assertEquals;

public class TodoBusinessImplStubTest {

    @Test
    public void usingAStub() {
        TodoService todoService = new TodoServiceStub();
        TodoBusinessImpl todoBusinessImpl = new TodoBusinessImpl(todoService);
        List<String> todos = todoBusinessImpl
                .retrieveTodosRelatedToSpring("ybmk");
        System.out.println(todos.size());
        assertEquals(2, todos.size());
    }
}