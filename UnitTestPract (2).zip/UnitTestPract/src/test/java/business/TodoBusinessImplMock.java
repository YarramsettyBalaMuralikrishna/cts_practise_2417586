package business;

import com.data.api.TodoService;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;


public class TodoBusinessImplMock {
    @Test
    public void testRetrive_usingMOck(){
        TodoService todoMock = mock(TodoService.class);
        List<String> todos = Arrays.asList("hello Learn world ","world Learn is a jello","bot but Learn bit bite");
        when(todoMock.retrieveTodos("ybmk")).thenReturn(todos);

        TodoBusinessImpl todoBusiness = new TodoBusinessImpl(todoMock);

        List<String> filtered = todoBusiness.retrieveTodosRelatedToSpring("ybmk");
        assertEquals(2, filtered.size());

    }
}
