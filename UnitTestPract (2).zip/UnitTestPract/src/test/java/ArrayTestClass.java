import org.junit.Test;

import java.util.Arrays;
import static org.junit.Assert.*;

public class ArrayTestClass {

    @Test
    public void checkArrayEquals(){
        int[] expected = {1,2,3,4,5};
        int[] actual = {2,0,3,1,4};
        Arrays.sort(actual);
        assertArrayEquals(expected, actual);
    }

    @Test(expected = NullPointerException.class)
    public void exceptionClass(){
        int [] a = {};
        Arrays.sort(a);
        assertTrue(a.length>0);
    }

}
