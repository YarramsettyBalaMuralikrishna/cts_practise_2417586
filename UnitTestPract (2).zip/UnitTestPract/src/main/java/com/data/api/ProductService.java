package com.data.api;

public interface ProductService {
    int getProductPrice(String productId);
}
