package business;

import com.data.api.TodoService;

import java.util.ArrayList;
import java.util.List;

// here TodoBusinessImpl is SUT - system under test


public class TodoBusinessImpl {

    //TodoService Dependency
    private TodoService todoService;

    TodoBusinessImpl(TodoService todoService) {
        this.todoService = todoService;
    }

    public List<String> retrieveTodosRelatedToSpring(String user) {
        List<String> filteredTodos = new ArrayList<String>();
        List<String> allTodos = todoService.retrieveTodos(user);
        System.out.println(allTodos);
        for (String todo : allTodos) {
            if (todo.contains("bala")) {
                filteredTodos.add(todo);
            }
        }
        return filteredTodos;
    }

}
