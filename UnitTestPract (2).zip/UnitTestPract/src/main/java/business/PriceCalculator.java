package business;

import com.data.api.ProductService;

public class PriceCalculator {
    private final ProductService productService;

    public PriceCalculator(ProductService productService){
        this.productService = productService;
    }

    public double calculateDiscount(String prodID){
        int price = productService.getProductPrice(prodID);
        return price * 0.90; // Apply 10% discount
    }
}
