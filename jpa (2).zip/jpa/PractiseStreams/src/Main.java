import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

class Person {
    private String name;
    private int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    @Override
    public String toString() {
        return "Name: " + name + ", Age: " + age;
    }
}

public class Main {
    public static void main(String[] args){
        String[] arr = {"sadf", "dsf", "wer","werqerf"};
        Optional<String> ans = Arrays.stream(arr).reduce((a,b) -> a+","+b);
        System.out.println(ans.get());
    }
}