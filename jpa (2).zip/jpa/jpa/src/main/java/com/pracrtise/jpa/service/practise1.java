package com.pracrtise.jpa.service;

import org.springframework.stereotype.Service;

@Service
public class practise1 {
    public String fetchId(String userId){
        System.out.println(userId);
        return "hii user" + userId+ "AOP    welcomes you";
    }
}
