package com.pracrtise.jpa.aop;


import com.pracrtise.jpa.enums.Roles;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class Practise1Aspect {

    @Before("execution(* com.pracrtise.jpa.service.practise1.fetchId(..))")
    public void beforePract1(JoinPoint joinPoint){
        String userId = (String) joinPoint.getArgs()[0];
        if(userId.equals("USER")) {
            System.out.println("hello USER how are you");

        }
    }

    @Around("execution(* com.pracrtise.jpa.controller.helloWorld.UserDetails(..))")
    public Object aroundHelloWorld(ProceedingJoinPoint proceedingJoinPoint) throws Throwable{

        Object[] args = proceedingJoinPoint.getArgs();
        Roles roles = (Roles) args[1];
        System.out.println(" around method is called");
        if(roles.equals(Roles.ADMIN)){
            Object result = proceedingJoinPoint.proceed();
            return  result;
        }else{
            return "Hey your role is user you are not authorised to look at this";
        }
    }
}
