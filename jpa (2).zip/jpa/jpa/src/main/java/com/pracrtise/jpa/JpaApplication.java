package com.pracrtise.jpa;

import com.pracrtise.jpa.service.practise1;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.CommandLineRunner;

@SpringBootApplication
public class JpaApplication implements  CommandLineRunner{

    @Autowired
    private practise1 practice;

	public static void main(String[] args) {
		SpringApplication.run(JpaApplication.class, args);
	}

    @Override
    public void run(String... args){
        String res = practice.fetchId("USER");
        System.out.print(res);
    }
}
