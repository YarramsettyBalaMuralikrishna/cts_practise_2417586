package com.pracrtise.jpa.controller;

import com.pracrtise.jpa.enums.Roles;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/aop")
public class helloWorld {
    @GetMapping("/hello")
    public String displayGreetings(){
        return "Hello world";
    }
    @GetMapping("/login/{name}/{role}")
    public String UserDetails(@PathVariable("name") String name,@PathVariable("role") Roles roles){
        return "Hello ADMIN: " +name + " how are you";
    }
}
