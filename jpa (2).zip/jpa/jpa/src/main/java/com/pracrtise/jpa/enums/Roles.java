package com.pracrtise.jpa.enums;

public enum Roles {
    ADMIN, USER;
}
