package org.example;

import java.util.*;

class Person {
    // Fields (Instance Variables)
    private String name;
    private int age;
    private double salary;

    // --- Constructors ---

    /**
     * No-argument constructor. Initializes fields to default values.
     */
    public Person() {
        this.name = "Unknown";
        this.age = 0;
        this.salary = 0.0;
    }

    /**
     * Parameterized constructor to initialize all fields.
     *
     * @param name   The name of the person.
     * @param age    The age of the person.
     * @param salary The salary of the person.
     */
    public Person(String name, int age, double salary) {
        this.name = name;
        this.age = age;
        this.salary = salary;
    }

    // --- Getters (Accessors) ---

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public double getSalary() {
        return salary;
    }

    // --- Setters (Mutators) ---

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    // --- toString() Method ---

    /**
     * Provides a string representation of the Person object.
     *
     * @return A formatted string with the person's details.
     */
    @Override
    public String toString() {
        return "Person{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", salary=" + String.format("%.2f", salary) + // Format salary to two decimal places
                '}';
    }
}

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    private final List<Person> personList;

    public static void main(String[] args) {
    }

    public Main(){
        this.personList = new ArrayList<>();

        Person p1 = new Person("Alice", 30, 75000.50);
        Person p2 = new Person("Bob", 22, 45000.00);

        // Using the no-arg constructor and setters
        Person p3 = new Person();
        p3.setName("Charlie");
        p3.setAge(45);
        p3.setSalary(95123.75);

        Person p4 = new Person("Dana", 58, 120000.00);
        Person p5 = new Person("Eve", 19, 30000.00);
        Person p6 = new Person("Frank", 70, 0.00);

        // Add all objects to the list
        this.personList.add(p1);
        this.personList.add(p2);
        this.personList.add(p3);
        this.personList.add(p4);
        this.personList.add(p5);
        this.personList.add(p6);
    }

    public String checkEquals(String s) {
        if (s.equals("dsfclkc")) {
            return "hello";
        } else {
            return "bye";
        }
    }

    public String maxLengthWord() {
        List<String> words = Arrays.asList("vasd", "vs", "wefd", "tygf", "ioulou");
        Optional<String> maxWord = words.stream().max(Comparator.comparingInt(String::length));
        return maxWord.get();
    }

    public Double maxSalary() {
        Optional<Person> ans = personList.stream().max(Comparator.comparingDouble(Person::getSalary));
        return ans.get().getSalary();

    }

    public boolean checkForAgeAcceptance(String name) {
//        System.out.println(personList);
        List<String> ans = personList.stream().
                filter(p -> p.getAge() > 30).
                map(p -> p.getName().toLowerCase()).
                toList();
        System.out.println(ans);
        for (String a : ans) {
            if (a.equals(name)) return true;
        }
        return false;
    }

}