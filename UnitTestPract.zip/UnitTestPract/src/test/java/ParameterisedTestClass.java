import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(Parameterized.class)
public class ParameterisedTestClass {

    private String ip;

    public ParameterisedTestClass(String ip) {
        this.ip = ip;
    }

    @Parameterized.Parameters
    public static Collection<String> checkForName(){
        String[] arr = {"bala","murali", "krishna"};
        return Arrays.asList(arr);
    }


    @Test
    public void test4(){
        assertEquals("bala", ip);
    }


}
