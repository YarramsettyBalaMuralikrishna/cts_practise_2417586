import org.example.Main;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.*;

public class MainTestClass {
    private String name;
    Main main = new Main();

    @Before
    public void beforeTests(){
        name = "hello world";
    }
    @BeforeClass
    public static void beforeClassTests(){
        System.out.println("before class tesst");
    }

    @After
    public void afterTest(){
        System.out.println("after tests");
    }

    @Test
    public void test(){
//        fail(" bhoom");

        final String expected = "bye";
        // expected value, actual value
        // to be followed cuz in case of success it dosent matter much but in case of failure then
        // we need to show that actual didnot match expected value soo to follow this we'll keep it as assertEquals(expected, actiual) format

        assertEquals(expected, main.checkEquals("dsafsad"));
    }
    @Test
    public void test2(){

        assertEquals("hello", main.checkEquals("doggy"));
    }
    @Test
    public void  test3(){
        assertEquals("ioulou", main.maxLengthWord());
    }

    @Test
    public void testForMaxSalary(){
        Double carry = 12000.0;
        assertEquals(carry, main.maxSalary());
    }

    @Test
    public void testForAgeCondition(){
        String name = "charlie";
        assertEquals(true, main.checkForAgeAcceptance(name));
    }

    @Test
    public void testBot(){
        System.out.println(name);
        int n = 3;
        assertTrue(main.checkForAgeAcceptance("cha"));

    }
}
